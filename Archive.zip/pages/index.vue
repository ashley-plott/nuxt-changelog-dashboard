
<script setup lang="ts">
await navigateTo('/dashboard')
</script>
<template></template>
